package com.naia.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.naia.mobile.ui.NaiaUiState
import com.naia.mobile.ui.Tab

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NaiaApp() }
    }
}

@Composable
fun NaiaApp() {
    var state by remember { mutableStateOf(NaiaUiState()) }
    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("NAIA Mobile") }) },
            bottomBar = {
                NavigationBar {
                    listOf("생성", "갤러리", "프리셋", "설정").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = state.selectedTab.ordinal == i,
                            onClick = { state = state.copy(selectedTab = Tab.entries[i]) },
                            icon = {},
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { pad ->
            when (state.selectedTab) {
                Tab.GENERATE -> GenerateScreen(state) { state = it }
                Tab.GALLERY -> SimpleScreen("이미지 갤러리", "생성된 이미지는 이 화면에서 관리할 수 있습니다.")
                Tab.PRESETS -> SimpleScreen("프리셋", "프롬프트 프리셋 저장 기능을 연결할 예정입니다.")
                Tab.SETTINGS -> SimpleScreen("설정", "NovelAI Persistent API Token은 안전한 저장소에 보관해야 합니다.")
            }
        }
    }
}

@Composable
private fun GenerateScreen(state: NaiaUiState, update: (NaiaUiState) -> Unit) {
    LazyColumn(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("이미지 생성", style = MaterialTheme.typography.headlineMedium) }
        item {
            OutlinedTextField(
                value = state.prompt,
                onValueChange = { update(state.copy(prompt = it)) },
                label = { Text("프롬프트") }, modifier = Modifier.fillMaxWidth(), minLines = 4
            )
        }
        item {
            OutlinedTextField(
                value = state.negativePrompt,
                onValueChange = { update(state.copy(negativePrompt = it)) },
                label = { Text("네거티브 프롬프트") }, modifier = Modifier.fillMaxWidth(), minLines = 2
            )
        }
        item {
            OutlinedButton(onClick = { update(state.copy(prompt = state.prompt + ", masterpiece, best quality")) }) {
                Text("추천 태그 추가")
            }
        }
        item {
            Button(onClick = { update(state.copy(isGenerating = true)) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (state.isGenerating) "생성 요청 대기" else "이미지 생성")
            }
        }
        item { Text("NovelAI API 연결은 토큰 보안 저장 및 실제 요청 스키마 검증 후 활성화됩니다.", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun SimpleScreen(title: String, description: String) {
    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        Text(description)
    }
}

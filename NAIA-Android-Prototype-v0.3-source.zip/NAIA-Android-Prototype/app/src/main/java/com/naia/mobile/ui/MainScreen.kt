package com.naia.mobile.ui

data class NaiaUiState(
    val prompt: String = "",
    val negativePrompt: String = "",
    val selectedTab: Tab = Tab.Generate,
    val isGenerating: Boolean = false,
)
enum class Tab { Generate, Gallery, Presets, Settings }

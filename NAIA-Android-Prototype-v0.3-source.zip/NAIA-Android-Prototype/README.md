# NAIA Android Prototype

초기 Android UI/구조 프로토타입입니다. 실제 NovelAI API 연동과 기존 NAIA 기능 이식 전 단계입니다.

## 목표
- 기존 NAIA의 어두운 UI 흐름 유지
- 한국어 중심 화면
- 생성 / 갤러리 / 프리셋 / 설정 탭
- API 토큰은 소스에 하드코딩하지 않고 Android Keystore 등 보안 저장소 사용

## 다음 구현 단계
1. 기존 웹 UI 및 API 요청 스키마 추가 분석
2. NovelAI 인증·생성 요청 모듈 구현
3. Room 기반 프리셋·갤러리 저장
4. 태그 인덱스와 자동완성 연결
5. 실제 Android 빌드 및 기기 테스트

> 이 폴더는 빌드 가능한 완성 APK가 아니라 초기 설계용 프로토타입 문서입니다.
